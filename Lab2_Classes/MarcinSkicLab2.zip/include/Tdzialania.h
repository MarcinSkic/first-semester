#ifndef TDZIALANIA_H
#define TDZIALANIA_H


class Tdzialania
{
private:
    int x,y;
public:
    void wczytaj();
    int iloczyn();
    float iloraz();
};

#endif // TDZIALANIA_H
